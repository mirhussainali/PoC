package com.exxonpoc;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class transformations

{
	// ---( internal utility methods )---

	final static transformations _instance = new transformations();

	static transformations _newInstance() { return new transformations(); }

	static transformations _cast(Object o) { return (transformations)o; }

	// ---( server methods )---




	public static final void transformString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(transformString)>> ---
		// @sigtype java 3.5
		// [i] field:1:required inputStringList
		// [i] field:0:required separator
		// [o] field:0:required concatString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	inputStringList = IDataUtil.getStringArray( pipelineCursor, "inputStringList" );
			String	separator = IDataUtil.getString( pipelineCursor, "separator" );
		pipelineCursor.destroy();
		
		if(separator == null)
			separator="";
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < inputStringList.length; i++) {
			sb.append(inputStringList[i]);
			if(i<inputStringList.length-1)
				sb.append(separator);
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "concatString", sb.toString() );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

